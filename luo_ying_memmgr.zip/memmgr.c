//
//  memmgr.c
//  memmgr
//
//  Created by Ying_Luo on 11/27/20.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

/* -----------------------------------------
                  Constants
   -----------------------------------------*/
#define ARGC_ERROR  1
#define FILE_ERROR  2
#define BUFLEN      256
#define MEMORY_SIZE 256 //Size of physical memory
#define TLB_SIZE    16
#define FRAME_SIZE  256
#define PAGE_SIZE   256
#define PAGE_TABEL_SIZE 256

/* -----------------------------------------
               Global Variables
   -----------------------------------------*/
int TLB[TLB_SIZE][2]; //TLB
int TLBFront = -1;    //Cirtular TLB FIFO front
int TLBEnd = -1;      //Cirtular TLB FIFO end
int pageTable[PAGE_TABEL_SIZE];        //Page table
char memory[MEMORY_SIZE][FRAME_SIZE];  //Physical memory
int memFrameFront = -1;                //Cirtular memory FIFO front
int memFrameEnd = -1;                  //Cirtular memory FIFO end
unsigned pageNum, offset, physicalAddr, frameNum;
unsigned logicalAddr;                                    // Read from file address.txt
unsigned correctLogiAddr, correctPhysAddr, correctValue; // Read from file correct.txt

/* -----------------------------------------
             Statistics variables
   -----------------------------------------*/
int pageFaultCnt = 0; // Number of page fault
int TLBHitCnt = 0;    // Number of TLB hit

/* -----------------------------------------
             Function Prototypes
   -----------------------------------------*/
unsigned getPageNum(unsigned x);

unsigned getOffset(unsigned x);

int translateAddr(unsigned logicalAddr, FILE* fbackstore);

void updateMemory(unsigned pageNum, FILE* fbackstore);

char accessMemory(unsigned physicalAddr);

void initTLB(void);

int lookupTLB(unsigned pageNum);

void updateTLB(unsigned pageNum, unsigned frameNum);

void initPageTable(void);

int lookupPageTable(unsigned pageNum);

void updatePageTable(unsigned pageNum, unsigned frameNum);

/* -----------------------------------------
             Program Main Driver
   -----------------------------------------*/
int main(int argc, const char* argv[]) {
    if (argc != 2) {
        printf("Error: argument invalid.\n");
        printf("Usage: ./memmgr <addresses file> \nExample: ./memmgr addresses.txt\n");
        exit(ARGC_ERROR);
    }
    
    FILE* faddr = fopen(argv[1], "r");    // open file addresses.txt  (contains the logical addresses)
    if (faddr == NULL) { fprintf(stderr, "Could not open file: 'addresses.txt'\n");  exit(FILE_ERROR);  }
    
    FILE* fcorr = fopen("correct.txt", "r");     // open file correct.txt (contains the logical and physical address, and its value)
    if (fcorr == NULL) { fprintf(stderr, "Could not open file: 'correct.txt'\n");  exit(FILE_ERROR);  }
    
    FILE* fbackstore = fopen("BACKING_STORE.bin", "r"); // open file BACKING_STORE.bin (contains the values of all logical addresses)
    if (fbackstore == NULL) { fprintf(stderr, "Could not open file: 'BACKING_STORE.bin'\n");  exit(FILE_ERROR);  }
    
    //initialization
    initTLB();
    initPageTable();
    
    char   buf[BUFLEN];
    size_t lineCnt = 0; //number of address references
    
    while (fscanf(fcorr, "%s %s %d %s %s %d %s %d", buf, buf, &correctLogiAddr, buf, buf, &correctPhysAddr, buf, &correctValue) > 0 && fscanf(faddr, "%d", &logicalAddr) > 0) {
        
        assert(logicalAddr == correctLogiAddr);

        //translate logical address to physical address
        physicalAddr = translateAddr(logicalAddr, fbackstore);
        //only compare physical address in correct.txt when physical memory is 256
        if (MEMORY_SIZE == 256) assert(physicalAddr == correctPhysAddr);
        
        //fetch value from memory using physical address
        int value = accessMemory(physicalAddr);
        assert(value == correctValue);
        
        printf("logical: %5u (page: %3u, offset: %3u) ---> physical: %5u, value: %4d -- passed\n", logicalAddr, pageNum, offset, physicalAddr, value);
        
        //grouping prints with 5 lines
        if (lineCnt % 5 == 4) printf("\n");
        lineCnt++;
    }
    
    fclose(fbackstore);
    fclose(fcorr);
    fclose(faddr);
    
    printf("ALL logical ---> physical assertions PASSED!\n\n");
    
    printf("Total address reference number is: %zu\n", lineCnt);
    printf("Total TLB hit number is: %u ---> TLB hit rate %3.3f\n", TLBHitCnt, (TLBHitCnt * 1.0) / lineCnt);
    printf("Total page fault number is: %u ---> Page fault rate %3.3f\n", pageFaultCnt, (pageFaultCnt * 1.0) / lineCnt);
    
    printf("\nDone...\n");
    
    return 0;
}

/* -----------------------------------------
             Function definitions
   -----------------------------------------*/
unsigned getPageNum(unsigned x) { return (0xff00 & x) >> 8; }

unsigned getOffset(unsigned x) { return (0xff & x); }

/* Translate logical to physical address. */
int translateAddr(unsigned logicalAddr, FILE* fbackstore)
{
    pageNum  = getPageNum(logicalAddr);
    offset   = getOffset(logicalAddr);
    int tlbResult = lookupTLB(pageNum);
    physicalAddr = 0;
    
    //TLB hit
    if (tlbResult != -1) {
        frameNum = tlbResult;
        physicalAddr = frameNum * FRAME_SIZE + offset;
        
        return physicalAddr;
    }
    
    //TLB miss, lookup page table
    int pageTableResult = lookupPageTable(pageNum);
    
    //Page table hit
    if (pageTableResult != -1) {
        frameNum = pageTableResult;
        physicalAddr = frameNum * FRAME_SIZE + offset;
        
        //update TLB
        updateTLB(pageNum, frameNum);
        
        return physicalAddr;
    }
    
    //Page fault, need swapping page between memory and backstore
    //load target page from backstore to memory
    updateMemory(pageNum, fbackstore);
    
    //calculate physical address
    frameNum = memFrameEnd;
    physicalAddr = frameNum * FRAME_SIZE + offset;
    
    //update page table after swapping page
    updatePageTable(pageNum, frameNum);
    
    //update TLB
    updateTLB(pageNum, frameNum);
    
    return physicalAddr;
}

/* Access memory with physical address to get value. */
char accessMemory(unsigned physicalAddr)
{
    unsigned memFrameNum = (0xff00 & physicalAddr) >> 8;
    unsigned memOffset = 0x00ff & physicalAddr;
    
    return memory[memFrameNum][memOffset];
}

/* Swap out a frame in memory and swap in new fram from
   backstore when page fault happened. */
void updateMemory(unsigned pageNum, FILE* fbackstore)
{
    char buf[PAGE_SIZE];
    
    //Seek to the beginning of the file
    fseek(fbackstore, pageNum * PAGE_SIZE, SEEK_SET);
    
    //read out the page that contains logical address
    fread(buf, sizeof(char), PAGE_SIZE, fbackstore);
    
    //Load page to memory when memory is empty
    if (memFrameFront == -1 && memFrameEnd == -1)
    {
        memFrameFront = 0;
        memFrameEnd = 0;
        
        memcpy(memory[memFrameEnd], buf, FRAME_SIZE * sizeof(char));
        
        return;
    }
    
    //Memory is not empty, use FIFO to evict frame in memory if necessary
    memFrameFront = (memFrameFront + 1) % MEMORY_SIZE;
    memFrameEnd = (memFrameEnd + 1) % MEMORY_SIZE;

    //swapping in new page in physical memory
    memcpy(memory[memFrameEnd], buf, FRAME_SIZE * sizeof(char));
}

/* Initialized TLB. */
void initTLB()
{
    for (int i = 0; i < TLB_SIZE; i++) {
        TLB[i][0] = -1;
        TLB[i][1] = -1;
    }
}

/* Lookup in TLB to find the pageNum -> frameNum mapping. */
int lookupTLB(unsigned pageNum)
{
    for (int i = 0; i < TLB_SIZE; i++)
    {
        //TLB hit happened
        if (TLB[i][0] == pageNum) {
            TLBHitCnt++;
            return TLB[i][1];
        }
    }
    
    //TLB miss
    return -1;
}

/* Update TLB with the recently used pageNum -> frameNum mapping. */
void updateTLB(unsigned pageNum, unsigned frameNum)
{
    //TLB is empty
    if (TLBFront == -1 && TLBEnd == -1)
    {
        TLB[0][0] = pageNum;
        TLB[0][1] = frameNum;
        
        TLBFront = 0;
        TLBEnd = 0;
        
        return;
    }

    //clear all TLB entries currently map from pageNum to frameNum
    //in case there will be duplicate mapping from pageNum to frameNum when
    for (int i = 0; i < TLB_SIZE; i++) {
        if (TLB[i][0] == pageNum) {
            TLB[i][0] = -1;
            TLB[i][1] = -1;
        }
    }
    
    //TLB is not empty, use FIFO to evict entry if necessary
    TLBFront = (TLBFront + 1) % TLB_SIZE;
    TLBEnd = (TLBEnd + 1) % TLB_SIZE;
    
    //Insert new entry at the end of the queue
    TLB[TLBEnd][0] = pageNum;
    TLB[TLBEnd][1] = frameNum;
}

/* Initialize Page Table. */
void initPageTable()
{
    for (int i = 0; i < PAGE_TABEL_SIZE; i++) {
        pageTable[i] = -1;
    }
}

/* Lookup page table for pageNum -> frameNum mapping.*/
int lookupPageTable(unsigned pageNum)
{
    //if page fault happened
    if (pageTable[pageNum] == -1) {
        pageFaultCnt++;
        return -1;
    }

    //return frame number
    return pageTable[pageNum];
}

/* Update page table with new pageNum -> frameNum mapping
   after a page failed. */
void updatePageTable(unsigned pageNum, unsigned frameNum)
{
    //clear all page table entries currently map from pageNum to frameNum
    //in case there will be duplicate mapping from pageNum to frameNum when
    //physical memory total frame number is less than page table entries
    for (int i = 0; i < PAGE_TABEL_SIZE; i++) {
        if (pageTable[i] == frameNum) pageTable[i] = -1;
    }
    
    pageTable[pageNum] = frameNum;
}